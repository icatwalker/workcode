JSManage.loadPlugin('js.dir1.dir2.alert',function($){

	return function(content,conf){

		var that ={};
		//TODO

        alert('我是 alert对象');

		return that;
	};
});
